echo "11" | ./bfques
